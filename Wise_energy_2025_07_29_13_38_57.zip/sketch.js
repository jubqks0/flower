function setup() {
  createCanvas(800, 800);
  background(255, 182, 193); // Fundo rosa claro
}

function draw() {
  // Definir a cor das pétalas
  fill(255, 105, 180);
  noStroke();

  // Definir o centro da flor no meio do canvas
  let cx = width / 2;
  let cy = height / 2;

  // Desenhar as pétalas
  ellipse(cx, cy - 50, 100, 150);  // Pétala superior
  ellipse(cx, cy + 50, 100, 150);  // Pétala inferior
  ellipse(cx - 50, cy, 150, 100);  // Pétala esquerda
  ellipse(cx + 50, cy, 150, 100);  // Pétala direita

  // Desenhar o centro da flor
  fill(255, 223, 0);  // Cor amarela para o centro
  ellipse(cx, cy, 80, 80);  // Centro da flor
}
